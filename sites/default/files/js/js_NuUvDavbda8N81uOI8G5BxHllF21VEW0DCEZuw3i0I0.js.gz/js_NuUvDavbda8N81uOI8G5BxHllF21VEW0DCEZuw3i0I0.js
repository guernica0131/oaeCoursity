/**
 * @file
 * Defines the behavior of the toolbar menu toggle button.
 */
(function ($) {

  Drupal.behaviors.toolbarMenuButton = {
    attach: function(context, settings) {
      var $tray = $('#navbar-tray');
      var $button = $('#toolbar-menu-button');
      var $oa_navbar = $('#oa-navbar');
      var $navbar = $('#navbar-bar');

      if ($navbar.length) {
        // move the shortcuts tray to the top of the admin menu tray
        var $shortcuts = $('#navbar-tray--2 .navbar-lining').children();
        if ($shortcuts.length && $tray.length) {
          var $short_tray = $shortcuts.detach();
          $('#navbar-tray .navbar-lining').prepend($short_tray);
        }
      }
      if ($tray.length && $button.length) {
        $button.unbind('click');
        $tray.removeClass('active'); // start closed
        $('body').removeClass('navbar-tray-open');
        $tray.addClass('navbar-tray-vertical'); // use vertical admin menu
        $tray.removeClass('navbar-tray-horizontal');
        $button.click(function(e) {
          $('body').toggleClass('navbar-tray-open');
          $tray.toggleClass('active');

          // When it's stickied, we need to push the tray down.
          if ($oa_navbar.css('position') !== 'static') {
            // Use attr for !important to override radix.
            $tray.attr('style', 'top: ' + $oa_navbar.height() + 'px !important');
          }
          else {
            $tray.attr('style', 'top: 0 !important');
          }
        });
      }
    }
  }

}(jQuery));
;
/**
 * @file
 * Manage spacing for dashboard and navbar tray.
 */

(function ($) {

  Drupal.behaviors.oaDashboard = {
    attach: function(context, settings) {
      var $oa_navbar = $('#oa-navbar');
      var $navbar = $('#navbar-bar');
      var $oa_responsive_navbar = $('#oa-responsive-regions-navbar');

      var $height = 0;
      if ($navbar.length) {
        // if using OA navbar, hide the navbar module's nav bar and remove its offset
        $navbar.hide();
        $navbar.removeAttr('data-offset-top');
      }
      if ($oa_navbar.length) {
        if ($oa_navbar.css('position') !== 'static') {
          $oa_navbar.attr('data-offset-top', '');
          $height = $oa_navbar.height();
        }
        else if ($oa_responsive_navbar.length) {
          $oa_responsive_navbar.attr('data-offset-top', '');
          $height = $oa_responsive_navbar.height();
        }
      }
      if (typeof(Drupal.displace) != "undefined") {
        Drupal.displace();  // recalculate offsets
      }
      else if ($height > 0) {
        // navbar not being used, so just offset the body padding
        $('body').css('padding-top', $height);
      }
    }
  }

}(jQuery));
;
(function($) {

  Drupal.behaviors.oa_toolbar_search = {
    attach: function(context, settings) {
      var $form = $('.toolbar-search form');
      var $search_bar = $form.find('.search-text');
      var $dropdown = $form.find('.dropdown-menu');
      var $dropdown_toggle = $form.find('.dropdown-toggle');

      if ($form.length) {
        $form.submit(function() {
          var term = $search_bar.val();
          var type = $dropdown.find('input:checked').val();
          $form.attr('action', determineSearchPath(term, type, settings.oa_search.space));
        });

        $dropdown.click(function(e) {
          e.stopPropagation();
        });
      }
    }
  };

  Drupal.behaviors.oa_sidebar_search = {
    attach: function(context, settings) {
      $('.pane-oa-sidebar-search form', context).each(function( index ) {
        var $form = $(this);
        var $search_bar = $form.find('.search-text');
        var $options = $form.find('.options');
        var $spaces = $form.find('.form-item-space-select');
        if ($form.length) {
          $form.submit(function() {
            var term = $search_bar.val();
            var type = $options.find('input:checked').val();
            var arg = 0;
            var argtext = '';
            if ($spaces.length) {
              arg = $spaces.find('select').val();
              argtext = $spaces.find('select option:selected').text();
              if (term.length === 0) {
                if ($options.hasClass('solr-search')) {
                  term = ' ';
                }
                else {
                  term = '*';
                }
              }
            }
            $form.attr('action', determineSearchPath(term, type, settings.oa_search.space, arg, argtext));
          });
        }
      });
    }
  };

  function determineSearchPath(term, type, space, arg, argtext) {
    var path =  Drupal.settings.basePath +  'search' + '/' + (type === 'users' ? 'user' : 'node') + '/' + term;
    if (type === 'this_space') {
      // %3A instead of : because of some weird double encoding on the backend.
      path += '?f[0]=' + encodeURIComponent('og_group_ref%3Atitle:' + space);
    }
    else if (arg > 0) {
      if (type === 'users') {
        path += '?f[0]=' + encodeURIComponent('og_user_node:' + arg);
      }
      else {
        path += '?f[0]=' + encodeURIComponent('og_group_ref%3Atitle:' + argtext);
      }
    }
    return path;
  }

})(jQuery);
;
(function ($) {

/**
 * Terminology:
 *
 *   "Link" means "Everything which is in flag.tpl.php" --and this may contain
 *   much more than the <A> element. On the other hand, when we speak
 *   specifically of the <A> element, we say "element" or "the <A> element".
 */

/**
 * The main behavior to perform AJAX toggling of links.
 */
Drupal.flagLink = function(context) {
  /**
   * Helper function. Updates a link's HTML with a new one.
   *
   * @param element
   *   The <A> element.
   * @return
   *   The new link.
   */
  function updateLink(element, newHtml) {
    var $newLink = $(newHtml);

    // Initially hide the message so we can fade it in.
    $('.flag-message', $newLink).css('display', 'none');

    // Reattach the behavior to the new <A> element. This element
    // is either whithin the wrapper or it is the outer element itself.
    var $nucleus = $newLink.is('a') ? $newLink : $('a.flag', $newLink);
    $nucleus.addClass('flag-processed').click(flagClick);

    // Find the wrapper of the old link.
    var $wrapper = $(element).parents('.flag-wrapper:first');
    if ($wrapper.length == 0) {
      // If no ancestor wrapper was found, or if the 'flag-wrapper' class is
      // attached to the <a> element itself, then take the element itself.
      $wrapper = $(element);
    }
    // Replace the old link with the new one.
    $wrapper.after($newLink).remove();
    Drupal.attachBehaviors($newLink.get(0));

    $('.flag-message', $newLink).fadeIn();
    setTimeout(function(){ $('.flag-message', $newLink).fadeOut() }, 3000);
    return $newLink.get(0);
  }

  /**
   * A click handler that is attached to all <A class="flag"> elements.
   */
  function flagClick() {
    // 'this' won't point to the element when it's inside the ajax closures,
    // so we reference it using a variable.
    var element = this;

    // While waiting for a server response, the wrapper will have a
    // 'flag-waiting' class. Themers are thus able to style the link
    // differently, e.g., by displaying a throbber.
    var $wrapper = $(element).parents('.flag-wrapper');
    if ($wrapper.is('.flag-waiting')) {
      // Guard against double-clicks.
      return false;
    }
    $wrapper.addClass('flag-waiting');

    // Hide any other active messages.
    $('span.flag-message:visible').fadeOut();

    // Send POST request
    $.ajax({
      type: 'POST',
      url: element.href,
      data: { js: true },
      dataType: 'json',
      success: function (data) {
        if (data.status) {
          // Success.
          data.link = $wrapper.get(0);
          $.event.trigger('flagGlobalBeforeLinkUpdate', [data]);
          if (!data.preventDefault) { // A handler may cancel updating the link.
            data.link = updateLink(element, data.newLink);
          }
          $.event.trigger('flagGlobalAfterLinkUpdate', [data]);
        }
        else {
          // Failure.
          alert(data.errorMessage);
          $wrapper.removeClass('flag-waiting');
        }
      },
      error: function (xmlhttp) {
        alert('An HTTP error '+ xmlhttp.status +' occurred.\n'+ element.href);
        $wrapper.removeClass('flag-waiting');
      }
    });
    return false;
  }

  $('a.flag-link-toggle:not(.flag-processed)', context).addClass('flag-processed').click(flagClick);
};

/**
 * Prevent anonymous flagging unless the user has JavaScript enabled.
 */
Drupal.flagAnonymousLinks = function(context) {
  $('a.flag:not(.flag-anonymous-processed)', context).each(function() {
    this.href += (this.href.match(/\?/) ? '&' : '?') + 'has_js=1';
    $(this).addClass('flag-anonymous-processed');
  });
}

String.prototype.flagNameToCSS = function() {
  return this.replace(/_/g, '-');
}

/**
 * A behavior specifically for anonymous users. Update links to the proper state.
 */
Drupal.flagAnonymousLinkTemplates = function(context) {
  // Swap in current links. Cookies are set by PHP's setcookie() upon flagging.

  var templates = Drupal.settings.flag.templates;

  // Build a list of user-flags.
  var userFlags = Drupal.flagCookie('flags');
  if (userFlags) {
    userFlags = userFlags.split('+');
    for (var n in userFlags) {
      var flagInfo = userFlags[n].match(/(\w+)_(\d+)/);
      var flagName = flagInfo[1];
      var contentId = flagInfo[2];
      // User flags always default to off and the JavaScript toggles them on.
      if (templates[flagName + '_' + contentId]) {
        $('.flag-' + flagName.flagNameToCSS() + '-' + contentId, context).after(templates[flagName + '_' + contentId]).remove();
      }
    }
  }

  // Build a list of global flags.
  var globalFlags = document.cookie.match(/flag_global_(\w+)_(\d+)=([01])/g);
  if (globalFlags) {
    for (var n in globalFlags) {
      var flagInfo = globalFlags[n].match(/flag_global_(\w+)_(\d+)=([01])/);
      var flagName = flagInfo[1];
      var contentId = flagInfo[2];
      var flagState = (flagInfo[3] == '1') ? 'flag' : 'unflag';
      // Global flags are tricky, they may or may not be flagged in the page
      // cache. The template always contains the opposite of the current state.
      // So when checking global flag cookies, we need to make sure that we
      // don't swap out the link when it's already in the correct state.
      if (templates[flagName + '_' + contentId]) {
        $('.flag-' + flagName.flagNameToCSS() + '-' + contentId, context).each(function() {
          if ($(this).find('.' + flagState + '-action').size()) {
            $(this).after(templates[flagName + '_' + contentId]).remove();
          }
        });
      }
    }
  }
}

/**
 * Utility function used to set Flag cookies.
 *
 * Note this is a direct copy of the jQuery cookie library.
 * Written by Klaus Hartl.
 */
Drupal.flagCookie = function(name, value, options) {
  if (typeof value != 'undefined') { // name and value given, set cookie
    options = options || {};
    if (value === null) {
      value = '';
      options = $.extend({}, options); // clone object since it's unexpected behavior if the expired property were changed
      options.expires = -1;
    }
    var expires = '';
    if (options.expires && (typeof options.expires == 'number' || options.expires.toUTCString)) {
      var date;
      if (typeof options.expires == 'number') {
        date = new Date();
        date.setTime(date.getTime() + (options.expires * 24 * 60 * 60 * 1000));
      } else {
        date = options.expires;
      }
      expires = '; expires=' + date.toUTCString(); // use expires attribute, max-age is not supported by IE
    }
    // NOTE Needed to parenthesize options.path and options.domain
    // in the following expressions, otherwise they evaluate to undefined
    // in the packed version for some reason...
    var path = options.path ? '; path=' + (options.path) : '';
    var domain = options.domain ? '; domain=' + (options.domain) : '';
    var secure = options.secure ? '; secure' : '';
    document.cookie = [name, '=', encodeURIComponent(value), expires, path, domain, secure].join('');
  } else { // only name given, get cookie
    var cookieValue = null;
    if (document.cookie && document.cookie != '') {
      var cookies = document.cookie.split(';');
      for (var i = 0; i < cookies.length; i++) {
        var cookie = jQuery.trim(cookies[i]);
        // Does this cookie string begin with the name we want?
        if (cookie.substring(0, name.length + 1) == (name + '=')) {
          cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
          break;
        }
      }
    }
    return cookieValue;
  }
};

Drupal.behaviors.flagLink = {};
Drupal.behaviors.flagLink.attach = function(context) {
  // For anonymous users with the page cache enabled, swap out links with their
  // current state for the user.
  if (Drupal.settings.flag && Drupal.settings.flag.templates) {
    Drupal.flagAnonymousLinkTemplates(context);
  }

  // For all anonymous users, require JavaScript for flagging to prevent spiders
  // from flagging things inadvertently.
  if (Drupal.settings.flag && Drupal.settings.flag.anonymous) {
    Drupal.flagAnonymousLinks(context);
  }

  // On load, bind the click behavior for all links on the page.
  Drupal.flagLink(context);
};

})(jQuery);
;
/**
 * @file
 * Manage spacing for banners in oa_appearance.
 */

(function ($) {

  Drupal.behaviors.oaAppearance = {
    attach: function(context, settings) {
      var $oa_navbar = $('#oa-navbar', context);
      var $banner = $('.oa-banner', context);
      if ($oa_navbar.length && $banner.length) {
        var $height = $oa_navbar.height();
        var $width = $oa_navbar.width();
        $delta_height = 0;
        $banner.each( function(index) {
          if (!$(this).hasClass('oa-banner-appeared') &&
              !$(this).hasClass('oa-banner-hidden')) {
            // set the image sizes before image gets loaded
            var $img_width = parseInt($(this).attr('data-width'));
            var $img_height = parseInt($(this).attr('data-height'));
            if ($img_width > 0) {
              // stretched banner image
              var $max_height = document.documentElement.clientHeight / 3;
              var $new_width = $new_height * $img_width / $img_height;
              var $new_height = Math.min( $img_height * $width / $img_width, $max_height);
              if ($(this).parents('#oa-navbar').length) {
                // this image is within the navbar
                $delta_height -= $(this).height();
                $delta_height += $new_height;
              }
              $(this).css('height', $new_height + 'px');
              $(this).css('max-height', $max_height + 'px');
              $(this).addClass('oa-banner-hidden');
              var $image = $('.oa-banner-overlay-img', this);
              if ($image.length) {
                $image.css('width', '100%');
              }
            }
            else {
              // non-stretching banner image
              $(this).addClass('oa-banner-appeared');
            }
          }
        });
        if ($delta_height > 0) {
          var $total_height = $height + $delta_height;
          $('body').css('padding-top', $total_height + 'px');
          if (typeof(Drupal.displace) != "undefined") {
            Drupal.displace();  // recalculate offsets
          }
          else {
            $oa_navbar.height($total_height);
          }
        }
      }
    }
  };

  $(window).load(function() {
    var $oa_navbar = $('#oa-navbar');
    var $image = $('.oa-banner-overlay-img');
    var $banner = $('.oa-banner');
    if ($banner.length) {
      $banner.each( function(index) {
        $(this).css( 'height', 'auto'); // let the banner resize from now on
        $(this).addClass('oa-banner-appeared');
        $(this).removeClass('oa-banner-hidden');
      });
    }
    if (($oa_navbar.length) && (typeof(Drupal.displace) == "undefined")) {
      $height = $oa_navbar.height();
      $('body').css('padding-top', $height + 'px');
    }
    // this is needed to allow bootstrap tour to display correctly
    $(window).trigger('resize');
  });

}(jQuery));
;
